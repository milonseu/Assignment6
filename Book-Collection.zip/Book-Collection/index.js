const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const app = express();
const port = 8080;

app.use(express.static('public'));

app.use(bodyParser.urlencoded({ extended: false }));

app.use(bodyParser.json());


app.get('/',(req,res)=>{
    res.sendFile(path.join(__dirname)+'/index.html')
});

app.get('/books',(req,res)=>{
    res.status(201).send([{

    }])
});

app.post('/books',(req,res)=>{
    let JSONData =req.body;
    res.send(JSONData);
});

app.delete('/books/:id',(req,res)=>{
    var id = req.params.id;

    if(id){
        res.send("the book are successfully deleted ");
        res.end();
    }
    else {
        res.send("the book are not deleted ");
        res.end();
    }

})

app.listen(port,()=>{
    console.log(`Server Run Successfully on port http://localhost:${port}`);
});